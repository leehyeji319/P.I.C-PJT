package com.lhj.pic.config;

public class Constant {
	
	/** 물리적 저장소 경로 */
	private static final String PHYSICAL_STORAGE_PATH = "C:\\PIC\\touristImages";
	
}
